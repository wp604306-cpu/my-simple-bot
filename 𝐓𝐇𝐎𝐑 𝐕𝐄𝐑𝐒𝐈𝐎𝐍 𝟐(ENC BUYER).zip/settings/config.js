global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6288985018505']
global.packname = "Sticker By HanzXD"
global.author = "HanzXDOfficial"
global.mess = {
 owner: '*You are not the owner*',
 premium: '*You are not premium*'
}